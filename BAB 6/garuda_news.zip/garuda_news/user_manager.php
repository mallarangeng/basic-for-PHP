<?php
	require("include/header.php");

	if (!$_SESSION['login']){
		echo "Anda tidak berhak mengakses halaman ini.";
		exit();
	}
	
	//Hapus user
	if (isset($_REQUEST['id']) && $_REQUEST['mode'] == 'delete'){
		$sqlstr = "DELETE FROM user WHERE id=".$_REQUEST['id'];
		$result = mysql_query($sqlstr) or die(mysql_error());
		$confirmation = ($result)? "Data telah terhapus." : 'Proses Gagal.';
			
	}
	
	//UPDATE MY PROFILE
	if (isset($_REQUEST['updateMyProfile'])){
		$email = mysql_real_escape_string($_REQUEST['myEmail']);
		$username = mysql_real_escape_string($_REQUEST['myUsername']);
		$password = mysql_real_escape_string($_REQUEST['myPassword']);
		if (!empty($password)){
			$pwdStr = ",password = '".md5($password)."'";
		}
		$sqlstr = "UPDATE user SET email ='".$email."',username='".$username."'".$pwdStr." WHERE id=".$_SESSION['userid'];
		$result = mysql_query($sqlstr) or die(mysql_error());
		
	}
	
	//REGISTER NEW USER
	if (isset($_REQUEST['register'])){
		$email = mysql_real_escape_string($_REQUEST['email']);
		$username = mysql_real_escape_string($_REQUEST['username']);
		$password = md5(mysql_real_escape_string($_REQUEST['password']));
		
		$sqlstr = "INSERT INTO user(email, username, password) ";
		$sqlstr .= "VALUES('".$email."','".$username."','".$password."')";
		$result = mysql_query($sqlstr) or die(mysql_error());
		if ($result)
			$confirmation =  "User telah terdaftar.";
		else
			$confirmation =  "Gagal untuk mendaftarkan user.";
	}
	
	//LOAD USER
	$userResult = mysql_query("SELECT * FROM user");
	?>
<div align="center">
	<div style="width:700px;text-align:left;padding-top:25px;">
	<br/>
	<?php echo $confirmation; ?>
	<form name="fUserList" method="post" action="<?php $_SERVER['PHP_SELF'] ?>">
	<table width="400px" border="1" cellpadding="2" cellspacing="0">
		<tr>
			<th>&nbsp;Email</th>
			<th>Username</th>
			<th>Action</th>
		</tr>
	
	<?php
	while ($userDt = mysql_fetch_array($userResult)){
	?>
		<tr>
			<td>&nbsp;<?php echo $userDt['email'];?></td>
			<td><?php echo $userDt['username'];?></td>
			<td><a href="./user_manager.php?id=<?php echo $userDt['id']; ?>&mode=delete">Hapus</a></td>
		</tr>
	<?php
	}
?>
	</table>
	</form>
	<br/>
	<script type="text/javascript">
		function validateRegistration(){
			email = document.getElementById('email').value;
			username = document.getElementById('username').value;
			password = document.getElementById('password').value;
			passwordConfirm = document.getElementById('passwordConfirm').value;
			
			if (email == ''){
				alert('Harap isi data email.');
				return false
			}else{
				if (validateEmailFormat(email)){
					if (username == ''){
						alert('Harap isi data username.');
						return false
					}else{
						if (password == ''){
							alert('Harap isi data password.')
							return false
						}else{
							if (passwordConfirm == ''){
								alert('Harap isi konfirmasi password.');
								return false;
							}else{
								if (password == passwordConfirm){
									return true;
								}else{
									alert('Password tidak cocok.');
									return false;
								}
							}
						}
					}
				}else{
					return false;
				}
			}
		}
	</script>
	<span style="font-weight:bold">Daftarkan user baru</span>
	<form name="fAddNew" method="post" action="<?php $_SERVER['PHP_SELF'] ?>" onsubmit="return validateRegistration()">
		<table width="80%" border="0" cellpadding="2" cellspacing="3">
			<tr>
				<td>Email</td>
				<td>:<input type="text" size="30px" id="email" name="email"/></td>
			</tr>
			<tr>
				<td>Username</td>
				<td>:<input type="text" id="username" name="username"/></td>
			</tr>
			<tr>
				<td>Password</td>
				<td>:<input type="password" id="password" name="password"/></td>
			</tr>
			<tr>
				<td>Konfirmasi Password</td>
				<td>:<input type="password" id="passwordConfirm" name="passwordConfirm"/></td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" name="register" value="Register"/></td>
			</tr>
		</table>
	</form>
	<hr/>
	<?php
		
	//LOAD MY PROFILE
		$result = mysql_query("SELECT * FROM user WHERE id = ".$_SESSION['userid']) or die(mysql_error());
		$data = mysql_fetch_object($result);
		$username = $data->username;
		$email = $data->email;
	?>
	<script type="text/javascript">
		function validateMyProfile(){
			email = document.getElementById('myEmail').value;
			username = document.getElementById('myUsername').value;
			password = document.getElementById('myPassword').value;
			passwordConfirm = document.getElementById('myPasswordConfirm').value;
			if (email == ''){
				alert('Please fill email textfield.')
				return false;
			}else{
				if (username == ''){
					alert('Please fill username textfield.')
					return false;
				}else{
					if (password == ''){
						return true;
					}else{
						if (passwordConfirm == password){
							return true;
						}else{
							alert('Password not match');
							return false;
						}
					}
				}
			}			
		}
	</script>
	<form name="fMyProfile" method="post" action="<?php $_SERVER['PHP_SELF'] ?>" onsubmit="return validateMyProfile()">
		<table width="80%" border="0" cellpadding="2" cellspacing="3">
			<tr>
				<td colspan="2" style="font-weight:bold;">My Profile Data</td>
			</tr>
			<tr>
				<td>Email</td>
				<td>:<input type="text" name="myEmail" id="myEmail" size="30px" value="<?php echo $email;?>"/></td>
			</tr>
			<tr>
				<td>Username</td>
				<td>:<input type="text" name="myUsername" id="myUsername" value="<?php echo $username;?>"/></td>
			</tr>
			<tr>
				<td>Password</td>
				<td>:<input type="password" name="myPassword" id="myPassword"/></td>
			</tr>
			<tr>
				<td>Confirm Password</td>
				<td>:<input type="password" name="myPasswordConfirm" id="myPasswordConfirm"/></td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" name="updateMyProfile" value="Update My Profile"/></td>
			</tr>
		</table>
	</form>
	</div>
</div>
<?php
	require("include/footer.php");
?>