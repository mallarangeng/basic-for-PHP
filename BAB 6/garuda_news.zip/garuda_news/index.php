<?php
	require("include/header.php");
?>

<div align="center">
	<div style="width:800px;text-align:left;">
		<div id="columnLeft">
			<?php
				//Tampilkan panel kiri
				require("include/news_subscription.php");
				require("include/kategori_berita.php");
				require("include/banner.php");
			?>
		</div>
		<div id="columnContent">
			<?php
				//Tampilkan panel content, jika catid dan newsid tidak kosong maka tampilkan berita terpilih, jika tidak tampilkan daftar berita
				if (!empty($_REQUEST['catid']) && !empty($_REQUEST['newsid']))
					require("include/lihat_berita.php");
				else
					require("include/news_listing.php");
			?>
		</div>
		
	</div>
	<div id="bottomContent">
		<div class="bottomContentPanel">
			<?php require("include/event.php"); ?>
		</div>
		<div class="bottomContentPanel">				
			<?php 				
				if ($_REQUEST['mode'] == "view_polling_result")
					//lihat hasil polling
					require("include/polling_result.php"); 
				else	
					//polling
					require("include/polling.php"); 					
			?>
		</div>
		<div class="bottomContentPanel">
			<?php require("include/tell_friends.php"); ?>
		</div>
	</div>

</div>


<?php
	require("include/footer.php");
?>