<?php
	require("include/header.php");
?>
<div align="center">
	<div style="width:700px;text-align:left;padding-top:25px;padding-left:25px;height:350px;">
<?php
	$q = mysql_real_escape_string($_REQUEST['q']);
	$result = mysql_query("SELECT * FROM berita WHERE judul LIKE '%".$q."%' OR isi_berita LIKE '%".$q."%'") or die(mysql_error());
	
	if (mysql_num_rows($result)>0){
		echo "<ul>";
		while ($data=mysql_fetch_array($result)){
			echo '<li>';
			echo '<a href="./?catid='.$data['id_kategori'].'&newsid='.$data['id'].'">'.$data['judul'].'</a><br/>';
			echo substr($data['isi_berita'],0,200)."...";
			echo '</li>';
		}
		echo "</ul>";
	}else{
		echo "Tidak ada data yang ditemukan.";
	}
?>		
	</div>
</div>
<?php
	require("include/footer.php");
?>