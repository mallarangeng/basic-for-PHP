<?php
	ob_start();	
	require("include/header.php");
	
	//Baca password dengan data username
	function getPassword($username){
		$sqlstr = "SELECT * FROM user WHERE username = '".$username."'";
		$result = mysql_query($sqlstr) or die(mysql_error());
		
		if (mysql_num_rows($result) == 1){
			$data=mysql_fetch_object($result);
			
			return $data->password."#".$data->id;
		}else{
			return "";
		}
	}
	
	if (isset($_REQUEST['signin'])){
		$username = trim($_REQUEST['username']);
		$password = trim($_REQUEST['password']);
		
		if (empty($username) or $username == 'username...'){
			echo "username masih kosong";
		}else{
			if (empty($password) or $password == 'Password...'){
				echo "Password masih kosong";
			}else{
				//Pecah nilai kembalian menjadi password dan user id
				$userInfoArr = explode("#",getPassword($username));
				
				$passwordAsli = $userInfoArr[0];
				$userid = $userInfoArr[1];
				
				if (empty($passwordAsli)){
					echo "User belum terdaftar.";
					exit();
				}
				
				if (md5($password) == $passwordAsli){
					$rememberme = $_REQUEST['rememberme'];
					//Jika remember me, buat cookie.
					if ($rememberme){
						setcookie('rememberme','true',time() + 7200);
						setcookie('userid',$userid,time() + 7200);
					}
					$_SESSION['userid'] = $userid;
					$_SESSION['login'] = true;
					header('location:index.php');
				}else{
					echo "Password salah";
				}
			}
		}
	}
		
	?>
<div align="center">
	<div style="width:800px;text-align:left;padding-left:170px;height:350px;">
		<br/>
		<form method="post" action="<?php $_SERVER['PHP_SELF']?>">
			<input type="text" name="username" value="Username..." onblur="if (this.value=='') 
			this.value='Username...'; " onfocus="if (this.value=='Username...')this.value=''"/>
			<input type="text" name="password" value="Password..." onblur="if (this.value==''){ 
			this.value='Password...';this.type='text';} " onfocus="if (this.value=='Password...')
			this.value='';this.type='password';"/><br/>
			<input type="checkbox" name="rememberme"/>Remember Me
			<input type="submit" value="Sign In" name="signin"/><br/>
			Lupa Password? <a href="recovery.php">Klik disini.</a>
		</form>
	</div>
</div>
<?php
	require("include/footer.php");
?>