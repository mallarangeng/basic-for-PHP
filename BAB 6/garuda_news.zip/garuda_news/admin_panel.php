<?php
	require("include/header.php");
	
	if (!$_SESSION['login']){
		echo 'Anda tidak berhak mengakses halaman ini. Silahkan <a href="login.php">login</a> terlebih dahulu.';
		exit();
	}
	
?>

<div align="center">
	<div style="width:400px;text-align:left;height:350px;padding-top:25px;">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td style="text-align:center;padding-bottom:15px;">
					<a class="admin_panel" href="news_manager.php">News Manager</a><br/><br/>
					<a href="news_manager.php">
						<img src="images/news.png" alt="news manager" width="64px" height="64px"/>
					</a>
				</td>
				<td style="text-align:center;padding-bottom:15px;">
					<a class="admin_panel" href="category_manager.php">Category Manager</a><br/><br/>
					<a href="category_manager.php">
						<img src="images/category.png" alt="user manager" width="64px" height="64px"/>
					</a>
				</td>
			</tr>
			<tr>
				<td style="text-align:center;padding-bottom:15px;">
					<a class="admin_panel" href="event_manager.php">Event Manager</a><br/><br/>
					<a href="event_manager.php">
						<img src="images/event.png" alt="event manager" width="64px" height="64px"/>
					</a>
				</td>
				<td style="text-align:center;padding-bottom:15px;">
					<a class="admin_panel" href="polling_manager.php">Polling Manager</a><br/><br/>
					<a href="polling_manager.php">
						<img src="images/polling.png" alt="polling manager" width="64px" height="64px"/>
					</a>
				</td>
			</tr>
			<tr>
				<td style="text-align:center;">
					<a class="admin_panel" href="banner_manager.php">Banner Manager</a><br/><br/>
					<a href="banner_manager.php">
						<img src="images/banner.png" alt="user manager" width="64px" height="64px"/>
					</a>
				</td>
				<td style="text-align:center;">
					<a class="admin_panel" href="user_manager.php">User Manager</a><br/><br/>
					<a href="user_manager.php">
						<img src="images/user.png" alt="user manager" width="64px" height="64px"/>
					</a>
				</td>
			</tr>
		</table>
	</div>
</div>


<?php
	require("include/footer.php");
?>