<?php
	require("include/header.php");
	$email = mysql_real_escape_string($_REQUEST['email']);
	$result = mysql_query("DELETE FROM pelanggan_berita WHERE email = '".$email."'") or die(mysql_error());
	
	if ($result)
		echo "Anda sudah tidak berlangganan lagi.";
	else
		echo "Proses gagal.";
	require("include/footer.php");
?>