<?php
	require("include/header.php");

	if (!$_SESSION['login']){
		echo "Anda tidak berhak mengakses halaman ini.";
		exit();
	}

	//SIMPAN DATA
	if (isset($_REQUEST['simpan'])){
		$kategori = mysql_real_escape_string($_REQUEST['kategori']);
		$id = $_REQUEST['id'];
		
		if (empty($id))
			$sqlstr = "INSERT INTO kategori_berita(kategori) VALUES('".$kategori."')";
		else
			$sqlstr = "UPDATE kategori_berita SET kategori = '".$kategori."' WHERE id =".$id;
		
		$result = mysql_query($sqlstr) or die(mysql_error());
		
		$confirmation = ($result)? "Data telah tersimpan.":"Gagal menyimpan data.";
		$kategori = "";
		$id = "";
	}
	
	//EDIT / DELETE MODE
	if (!empty($_REQUEST['id']) && !empty($_REQUEST['mode'])){
		if ($_REQUEST['mode'] == 'delete'){
			$result = mysql_query("DELETE FROM kategori_berita WHERE id=".$_REQUEST['id']) or die(mysql_error());
			$confirmation = ($result)? "Data telah terhapus.":"Gagal menghapus data.";
		}elseif ($_REQUEST['mode'] == 'edit'){
			$result = mysql_query("SELECT * FROM kategori_berita WHERE id=".$_REQUEST['id']) or die(mysql_error());
			$data = mysql_fetch_array($result);
			$id = $data['id'];
			$kategori = $data['kategori'];
		}
	}
	?>
<div align="center">
	<div style="width:700px;text-align:left;padding-top:25px;">
	<div class="pageTitle">Category Manager</div>
	<?php echo $confirmation; ?><br/>
	<form method="get" action="<?php $_SERVER['PHP_SELF'] ?>">
		Kategori : <input type="text" name="kategori" value="<?php echo $kategori;?>"/><input type="submit" name="simpan" value="Simpan"/>
		<input type="hidden" name="id" value="<?php echo $id;?>" />
	</form>
	<hr/>
	<table border="1" cellpadding="2" cellspacing="0">
		<tr>
			<th>Kategori Berita</th>
			<th>Action</th>
		</tr>
		<?php
		//LOAD USER
		$result = mysql_query("SELECT * FROM kategori_berita");
		while ($data = mysql_fetch_array($result)){
		?>
			<tr>
				<td><?php echo $data['kategori'];?></td>
				<td>
					<a href="./category_manager.php?id=<?php echo $data['id']; ?>&mode=delete">Hapus</a> | 
					<a href="./category_manager.php?id=<?php echo $data['id']; ?>&mode=edit">Edit</a>
				</td>
			</tr>
		<?php
		}
		?>
	</table>
	</div>
</div>
<?php	
	require("include/footer.php");
?>