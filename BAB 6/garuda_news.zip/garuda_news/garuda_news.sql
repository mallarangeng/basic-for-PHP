-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 16, 2010 at 09:56 
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `garuda_news`
--

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE IF NOT EXISTS `banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gambar` varchar(100) NOT NULL,
  `link` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `gambar`, `link`) VALUES
(3, 'resources/garuda_media.jpg', 'http://www.garudamedia.co.id'),
(5, 'resources/karisma.jpg', 'http://www.karismakomputer.com');

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE IF NOT EXISTS `berita` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_kategori` int(11) NOT NULL,
  `judul` varchar(50) NOT NULL,
  `isi_berita` text NOT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id`, `id_kategori`, `judul`, `isi_berita`, `tanggal`) VALUES
(3, 10, 'Lorem ipsum dolo sit amet', '<p>\r\n	Lorem ipsum dolo sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>\r\n<p>\r\n	Lorem ipsum dolo sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>\r\n<p>\r\n	Lorem ipsum dolo sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>\r\n<p>\r\n	Lorem ipsum dolo sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.</p>\r\n', '2010-03-02'),
(4, 3, 'internasional blablabalbalbalablab', '<p>\r\n	blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional blabalbalbalblbala internasional</p>\r\n', '2010-03-05'),
(6, 6, 'Garuda Media', '<p>\r\n	<strong>Garuda</strong><img align="left" alt="garuda_media" height="60" hspace="1" src="./resources/garuda_media.jpg" width="200" /><strong> Media</strong> merupakan perusahan industri kreatif anak bangsa yang bergerak di bidang IT Multimedia, hadir dengan visi&nbsp; menjadi yang terdepan dalam mengembangkan teknologi pendidikan berbasis multimedia.<br />\r\n	Garuda Media mengemas berbagai materi terkini seputar dunia teknologi dan informasi ke dalam bentuk CD Tutorial Interactive &amp; buku digital sehingga lebih mudah dipelajari oleh pengguna, fleksibel dan seperti dididik langsung oleh seorang profesional.<br />\r\n	Garuda Media didukung oleh instruktur dan pemateri yang ahli di bidangnya dan telah berpengalaman bertahun-tahun sebagai praktisi dan pengajar di bidang pendidikan komputer, sehingga mengetahui seluk-beluk pemilihan materi dan cara penyampaian yang tepat dan menarik.</p>\r\n', '2010-03-12'),
(13, 7, 'Lorem ipsum dolor sit amet', '<p>\r\n	<img align="left" alt="waterfall" height="110" hspace="2" src="./resources/Waterfall.jpg" style="width: 133px; height: 110px;" width="133" />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam pulvinar, sapien et eleifend tincidunt, nulla mi laoreet lorem, eu posuere nisl turpis commodo ipsum. Etiam ultrices scelerisque nibh, eget rutrum lacus fringilla nec. Praesent quis lorem sed ligula elementum tempus. Duis varius eros id mi fringilla interdum vel sed leo. Mauris commodo blandit lectus, et pharetra nibh suscipit a. Nulla velit massa, molestie condimentum convallis et, scelerisque ut ante. Curabitur sit amet cursus dui. Sed non mi est. Quisque aliquam ipsum nec nibh auctor dignissim. Fusce at posuere leo. Fusce euismod metus vel metus interdum mollis. Quisque ac neque magna, in pharetra mauris. Suspendisse potenti. Quisque porta dapibus justo nec ultricies. Nulla facilisi. Aenean erat urna, dapibus in aliquam non, vehicula eu nibh. Pellentesque ultrices augue erat, eget interdum ligula.<br />\r\n	<br />\r\n	Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque et lorem dui. Fusce volutpat turpis sed dui facilisis volutpat. Suspendisse tortor augue, facilisis at venenatis vitae, suscipit et sem. Nullam vitae nisi a massa vehicula tincidunt. Integer sit amet dolor lacus. Quisque iaculis gravida nunc sed vehicula. Mauris et lorem nec ante congue tincidunt. Suspendisse hendrerit bibendum sapien non tincidunt. Nunc vitae magna sed urna accumsan rutrum. Nulla facilisi. Duis metus magna, dignissim a consectetur pellentesque, ullamcorper quis quam. Donec risus felis, dictum sit amet vulputate in, congue at neque.</p>\r\n', '2010-03-13'),
(11, 7, 'consectetur adipiscing elit. Nam pulvinar', '<p>\r\n	<img align="left" alt="" hspace="3" src="./resources/Humpback Whale.jpg" style="width: 142px; height: 105px;" />Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam pulvinar, sapien et eleifend tincidunt, nulla mi laoreet lorem, eu posuere nisl turpis commodo ipsum. Etiam ultrices scelerisque nibh, eget rutrum lacus fringilla nec. Praesent quis lorem sed ligula elementum tempus. Duis varius eros id mi fringilla interdum vel sed leo. Mauris commodo blandit lectus, et pharetra nibh suscipit a. Nulla velit massa, molestie condimentum convallis et, scelerisque ut ante. Curabitur sit amet cursus dui. Sed non mi est. Quisque aliquam ipsum nec nibh auctor dignissim. Fusce at posuere leo. Fusce euismod metus vel metus interdum mollis. Quisque ac neque magna, in pharetra mauris. Suspendisse potenti. Quisque porta dapibus justo nec ultricies. Nulla facilisi. Aenean erat urna, dapibus in aliquam non, vehicula eu nibh. Pellentesque ultrices augue erat, eget interdum ligula.<br />\r\n	<br />\r\n	Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque et lorem dui. Fusce volutpat turpis sed dui facilisis volutpat. Suspendisse tortor augue, facilisis at venenatis vitae, suscipit et sem. Nullam vitae nisi a massa vehicula tincidunt. Integer sit amet dolor lacus. Quisque iaculis gravida nunc sed vehicula. Mauris et lorem nec ante congue tincidunt. Suspendisse hendrerit bibendum sapien non tincidunt. Nunc vitae magna sed urna accumsan rutrum. Nulla facilisi. Duis metus magna, dignissim a consectetur pellentesque, ullamcorper quis quam. Donec risus felis, dictum sit amet vulputate in, congue at neque.</p>\r\n', '2010-03-13'),
(12, 7, 'Etiam ultrices scelerisque nibh', '<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam pulvinar, sapien et eleifend tincidunt, nulla mi laoreet lorem, eu posuere nisl turpis commodo ipsum. Etiam ultrices scelerisque nibh, eget rutrum lacus fringilla nec. Praesent quis lorem sed ligula elementum tempus. Duis varius eros id mi fringilla interdum vel sed leo. Mauris commodo blandit lectus, et pharetra nibh suscipit a. Nulla velit massa, molestie condimentum convallis et, scelerisque ut ante. Curabitur sit amet cursus dui. Sed non mi est. Quisque aliquam ipsum nec nibh auctor dignissim. Fusce at posuere leo. Fusce euismod metus vel metus interdum mollis. Quisque ac neque magna, in pharetra mauris. Suspendisse potenti. Quisque porta dapibus justo nec ultricies. Nulla facilisi. Aenean erat urna, dapibus in aliquam non, vehicula eu nibh. Pellentesque ultrices augue erat, eget interdum ligula.<br />\r\n	<br />\r\n	Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque et lorem dui. Fusce volutpat turpis sed dui facilisis volutpat. Suspendisse tortor augue, facilisis at venenatis vitae, suscipit et sem. Nullam vitae nisi a massa vehicula tincidunt. Integer sit amet dolor lacus. Quisque iaculis gravida nunc sed vehicula. Mauris et lorem nec ante congue tincidunt. Suspendisse hendrerit bibendum sapien non tincidunt. Nunc vitae magna sed urna accumsan rutrum. Nulla facilisi. Duis metus magna, dignissim a consectetur pellentesque, ullamcorper quis quam. Donec risus felis, dictum sit amet vulputate in, congue at neque.</p>\r\n', '2010-03-13');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE IF NOT EXISTS `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event` varchar(30) NOT NULL,
  `keterangan` tinytext NOT NULL,
  `tempat` varchar(50) NOT NULL,
  `mulai` date NOT NULL,
  `selesai` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`id`, `event`, `keterangan`, `tempat`, `mulai`, `selesai`) VALUES
(7, 'Pameran Komputer', 'balbalbalblsfbaksjfhanlsuhflnkashfkashfksjhfkjs', 'Dieng Plaza', '2010-03-15', '2010-03-29'),
(8, 'Job Fair', 'Dihadiri sejumlah perusahaan - perusahaan ternama baik domestik ataupun internasional', 'Widyaloka Brawijaya', '2010-03-11', '2010-03-25'),
(6, 'Jalan Sehat', 'blabalbalbaablabl', 'Lapangan Rampal Malang', '2010-03-28', '2010-03-28'),
(5, 'Pameran Buku', 'Menghadirkan Talkshow Raditya "Kambing" Dika, Dewi "Dee" Lestari, Moammar Emka', 'Perpustakaan Kota Malang', '2010-03-04', '2010-03-19'),
(9, 'Seminar IP Phone', 'Pembicara Onno W. Purbo, Fasilitas Free Hotspot, Snack, sertifikat, book note.', 'Aula Poltek', '2010-03-15', '2010-03-15'),
(10, 'Charity Concert For Chile', 'Presenting Bon jovi, King of Convenience, Paramore, Jason Mraz, James Blunt. HTM: Rp. 1.500.000,00', 'UMM Dome', '2010-03-27', '2010-03-27'),
(11, 'L.A Night Concert', '', 'Rampal', '2010-03-20', '2010-03-20'),
(12, 'Toyota Road Show', '', 'Malang Olympic Garden(MOG)', '2010-03-22', '2010-03-28'),
(13, 'Book Fair', '', 'UMM Dome', '2010-03-15', '2010-03-21');

-- --------------------------------------------------------

--
-- Table structure for table `image_gallery`
--

CREATE TABLE IF NOT EXISTS `image_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(20) NOT NULL,
  `path` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `image_gallery`
--

INSERT INTO `image_gallery` (`id`, `title`, `path`) VALUES
(1, 'Autumn Leaves', 'resources/Autumn Leaves.jpg'),
(2, 'Creek', 'resources/Creek.jpg'),
(3, 'Garuda Media', 'resources/garuda_media.jpg'),
(4, 'Forest', 'resources/Forest.jpg'),
(5, 'Waterfall', 'resources/Waterfall.jpg'),
(6, 'Sunset', 'resources/sunset.jpg'),
(7, 'Humpback Whale', 'resources/Humpback Whale.jpg'),
(8, 'Desert Landscape', 'resources/Desert Landscape.jpg'),
(9, 'Dock', 'resources/Dock.jpg'),
(10, 'Forest Flowers', 'resources/Forest Flowers.jpg'),
(11, 'Frangipani Flowers', 'resources/Frangipani Flowers.jpg'),
(12, 'Garden', 'resources/Garden.jpg'),
(13, 'Turtle', 'resources/Green Sea Turtle.jpg'),
(14, 'Oryx Antelope', 'resources/Oryx Antelope.jpg'),
(15, 'Toco Toucan', 'resources/Toco Toucan.jpg'),
(16, 'Tree', 'resources/Tree.jpg'),
(17, 'Winter Leaves', 'resources/Winter Leaves.jpg'),
(18, 'Karisma', 'resources/karisma.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `kategori_berita`
--

CREATE TABLE IF NOT EXISTS `kategori_berita` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kategori` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `kategori_berita`
--

INSERT INTO `kategori_berita` (`id`, `kategori`) VALUES
(2, 'Nasional'),
(3, 'Internasional'),
(4, 'Sepakbola'),
(5, 'Olahraga'),
(6, 'Iptek'),
(7, 'Bisnis'),
(8, 'Otomotif'),
(9, 'Kesehatan'),
(10, 'Piala Dunia 2010');

-- --------------------------------------------------------

--
-- Table structure for table `pelanggan_berita`
--

CREATE TABLE IF NOT EXISTS `pelanggan_berita` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pelanggan_berita`
--


-- --------------------------------------------------------

--
-- Table structure for table `poll_answer`
--

CREATE TABLE IF NOT EXISTS `poll_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `answer` varchar(20) NOT NULL,
  `color_code` varchar(6) NOT NULL,
  `point` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `poll_answer`
--

INSERT INTO `poll_answer` (`id`, `question_id`, `answer`, `color_code`, `point`) VALUES
(11, 2, 'Prancis', '864156', 0),
(10, 2, 'Italia', '443888', 1),
(9, 2, 'Spanyol', '689554', 0),
(8, 2, 'Inggris', '798746', 0),
(7, 2, 'Brazil', '811502', 0);

-- --------------------------------------------------------

--
-- Table structure for table `poll_question`
--

CREATE TABLE IF NOT EXISTS `poll_question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poll_name` varchar(20) NOT NULL,
  `question` varchar(50) NOT NULL,
  `expired` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `poll_question`
--

INSERT INTO `poll_question` (`id`, `poll_name`, `question`, `expired`) VALUES
(2, 'Piala Dunia 2010', 'Siapakah juara piala dunia 2010', '2010-03-24');

-- --------------------------------------------------------

--
-- Table structure for table `poll_voter`
--

CREATE TABLE IF NOT EXISTS `poll_voter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) NOT NULL,
  `answer_id` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `poll_voter`
--

INSERT INTO `poll_voter` (`id`, `question_id`, `answer_id`, `ip`, `date`) VALUES
(4, 2, 10, '127.0.0.1', '2010-03-13');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`) VALUES
(1, 'kasumayuda', 'e10adc3949ba59abbe56e057f20f883e', 'kasuma.yuda@gmail.com'),
(4, 'support', 'e10adc3949ba59abbe56e057f20f883e', 'support@garudanews.co.cc');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
