<?php
	require("include/header.php");
	
	//Hapus berita
	if ($_REQUEST['mode'] == "delete"){
		$id = $_REQUEST['id'];
		$result = mysql_query("DELETE FROM berita WHERE id =".$id) or die(mysql_error());
		
		$confirmation = ($result) ? "Data telah terhapus." : "Gagal menghapus data."; 
	}
?>
<div align="center">
	<div style="width:700px;text-align:left;padding-top:25px;">
		<form method="get" action="<?php $_SERVER['PHP_SELF'] ?>">
		<?php
			//LOAD KATEGORI
			$result = mysql_query("SELECT * FROM kategori_berita ORDER BY kategori ASC") or die(mysql_error());
		?>
		Pilih Kategori Terlebih dahulu 	<select name="kategori" onchange="submit();">
										<?php
										if (empty($_REQUEST['kategori'])) echo '<option value="" selected="selected">--Kategori--</option>';
										while ($data=mysql_fetch_array($result)){
											?><option <?php if ($_REQUEST['kategori'] == $data['id']) echo 'selected="selected"' ?> value="<?php echo $data['id']; ?>"><?php echo $data['kategori']; ?></option>
										<?php
											
										}
										?>							
									</select><br/>
						<a class="topLink" href="input_berita.php?kategori=<?php echo $_REQUEST['kategori']; ?>">Berita Baru >></a>
					   
		<?php
			if (!empty($_REQUEST['kategori'])){
				//LOAD NEWS
				$result = mysql_query("SELECT * FROM berita WHERE id_kategori=".$_REQUEST['kategori']." ORDER BY tanggal DESC") or die(mysql_error());
				?>
				<table border="1" cellpadding="2" cellspacing="0">
					<tr>
						<th>Judul</th><th>Tanggal</th><th>Action</th>
					</tr>
					<?php
					while ($data = mysql_fetch_array($result)){
						echo '<tr>';
							echo '<td>'.$data['judul'].'</td>';
							echo '<td>'.$data['tanggal'].'</td>';
							echo '<td><a href="news_manager.php?mode=delete&id='.$data['id'].'&kategori='.$data['id_kategori'].'">Hapus</a> |<a href="input_berita.php?kategori='.$data['id_kategori'].'&id='.$data['id'].'">Edit</a></td>';
						echo '</tr>';
					}
					?>
				</table>
				<?php
			}
		?>
		</form>
	</div>
</div>
<?php
	require("include/footer.php");
?>