<?php
	require("include/header.php");
?>
<style type="text/css">
  td, input{ font-style:verdana; font-size:14px; }
</style>

<?php
  if (isset($_REQUEST['simpan'])){
    $nama = $_REQUEST['nama'];
    $email = $_REQUEST['email'];
    $pesan = $_REQUEST['pesan'];
	$subjek = $_REQUEST['subjek'];
    
	$to = "garuda-news@yahoo.com";
    $header = "from: $email \n";
    $header .= "Content-Type: text/html \r \n";
    $sendMail = mail($to,$subjek,$pesan,$header);
	
	$confirmation = ($sendMail)? "Terimakasih telah menghubungi kami.":"Proses gagal, silahkan ulangi sekali lagi.";
  }
?>
<div align="center">
	<div style="width:700px;text-align:left;padding-top:25px;margin-left:75px;">
		<?php
			echo $confirmation;
		?>
		<form method="get" action="<?php $_SERVER['PHP_SELF'] ?>">
		  <table border="0" cellpadding="1" cellspacing="0">
			<tr>
			  <td>Nama</td>
			  <td><input type="text" name="nama" size="30px"/></td>
			</tr>
			<tr>
			  <td>E-Mail </td>
			  <td><input type="text" name="email" size="30px"/></td>
			</tr>
			<tr>
			  <td>Subjek </td>
			  <td><input type="text" name="subjek" size="50px"/></td>
			</tr>
			<tr>
			  <td valign="top">Pesan</td>
			  <td valign="top"><textarea rows="8" cols="50" name="pesan"></textarea></td>
			</tr>
			<tr>
			  <td colspan="2"><input type="submit" name="simpan" value="Simpan"/></td>
			</tr>
		  </table>
		</form>
	</div>
</div>
<?php
	require("include/footer.php");
?>