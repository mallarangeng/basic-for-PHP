<?php
	require("include/header.php");
?>

<div align="center">
	<div style="width:700px;text-align:left;padding-top:25px;">
		
	<?php
		$result = mysql_query("SELECT * FROM event WHERE selesai >= NOW()") or die(mysql_error());
		while ($data = mysql_fetch_array($result)){
			echo '<div id="'.$data['id'].'" style="border-bottom:dashed 1px #fd0000;">';
			echo 'Event : '.$data['event'].'<br/>';
			echo 'Tempat : '.$data['tempat'].'<br/>';
			echo 'Tanggal : '.readDate($data['mulai']).' - '.readDate($data['selesai']).'<br/>';
			echo 'Keterangan : '.$data['keterangan'].'<br/>';
			echo '</div><br/>';
		}
	?>
	</div>
</div>

<?php	
	require("include/footer.php");
?>