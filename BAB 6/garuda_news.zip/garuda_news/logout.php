<?php
	setcookie('rememberme','');
	setcookie('userid','');
	session_start();
	session_destroy();
	header('location:index.php');
?>