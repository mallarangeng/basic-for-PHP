<?php
	//Cek format email
	function cekEmailFormat($email){
		if (!ereg('^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])$',$email))
			return false;
		else
			return true;
	}
	
	//Beritahu teman saya
	if (isset($_REQUEST['submit'])){
		$name = $_REQUEST['nama'];
		$email = $_REQUEST['myEmail'];
		$emailAddressArr = $_REQUEST['email'];
		
		$emailFormat = false;	
		//Jika email anda benar dan field nama tidak kosong proses email teman.
		if (cekEmailFormat($email) && !empty($name)){
	
			for ($i=0;$i<=2;$i++){
				//Jika list email kosong, lanjutkan looping
				if (empty($emailAddressArr[$i])) continue;
				//Cek format email
				if (cekEmailFormat($emailAddressArr[$i])){
					$emailAddressList .= $emailAddressArr[$i]. ",";
					$emailFormat = true;
				}else{
					//$confirmation = "Email teman anda salah.";
					$emailFormat = false;
				}
			}
			
			//Jika field email teman masih kosong, beri konfirmasi
			if (empty($emailAddressList)) $confirmation = "Email teman anda masih kosong/ email teman anda salah.";
			
		}else{
			$confirmation = "Format email anda salah atau nama anda masih kosong.";
		}
		
		//Jika format email benar, maka beritahu teman - teman.
		if ($emailFormat){
			//Hilangkan koma paling belakang.
			$emailAddressList = substr($emailAddressList,0,strlen($emailAddressList) -1 );
			
			//tell my friends...
			$from = "from: admin garudanews \r\n";
			$from .= "Content-type: text/html \r\n";
			
			$subject = "Visit garudanews.";
			
			$emailBody = '<p>Hai...</p>';
			$emailBody .= '<p>	Teman anda yang bernama '.$name.' telah mereferensikan anda untuk mengunjungi website kami, yaitu: <a href="http://www.garuda-news.co.cc/" target="_blank">garudanews</a>.</p>';
			$emailBody .= '<p>	&nbsp;</p>';
			$emailBody .= '<p>	salam,</p>';
			$emailBody .= '<p>	&nbsp;</p>';
			$emailBody .= '<p>	garudanews crew</p>';

			$kirim = mail($emailAddressList, $subject, $emailBody, $from);
				
			if ($kirim){
				$confirmation =  "Terima kasih telah mereferensikan teman anda untuk bergabung di website kami";
			}else{
				$confirmation =  "Maaf terjadi kesalahan saat pemrosesan data. Silahkan ulangi sekali lagi atau hubungi administrator kami.";
			}
		}
	}
?>
<div class="headerStyle">
	<div style="padding:4px 0px;">&nbsp;<img src="images/header_left.jpg"/>&nbsp;Tell Friends</div>
</div>
<div style="width:98%">
	<?php
		echo $confirmation;
	?>
	<form method="post" action="<?php $_SERVER['PHP_SELF'] ?>" onsubmit="validateTellFriends()">
		<table border="0" cellpadding="0" cellspacing="1">
			<tr>
				<td>Nama Anda</td>
				<td><input type="text" name="nama"/></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="myEmail"/></td>
			</tr>
			<tr>
				<td colspan="2"><hr/></td>
			</tr>
			<tr>
				<td>Email Teman 1</td>
				<td><input id="email1" name="email[]"/></td>
			</tr>
			<tr>
				<td>Email Teman 2</td>
				<td><input id="email2" name="email[]"/></td>
			</tr>
			<tr>
				<td>Email Teman 3</td>
				<td><input id="email3" name="email[]"/></td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" name="submit" value="Kirim"/></td>
			</tr>
		</table>
	</form>
</div>