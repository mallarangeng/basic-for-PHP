<?php
	//Dapatkan nama kategori berita
	/*function getIdKategori($kategori){
		$result = mysql_query("SELECT id FROM kategori_berita WHERE kategori ='".$kategori."'") or die(mysql_error());
		$data = mysql_fetch_array($result);
		return $data['id'];
	}*/
	
	$catId = $_REQUEST['catid'];
	$idjudul = $_REQUEST['newsid'];
	$result = mysql_query("SELECT * FROM berita WHERE id='".$idjudul."'") or die(mysql_error());
	if (mysql_num_rows($result)>0){
		$data = mysql_fetch_array($result);
		echo '<div class="newsTitle">'.$data['judul'].'</div>';
		$tanggalArr = explode("-",$data['tanggal']);
		echo '<div class="datePublish">'.$tanggalArr[2].'-'.$tanggalArr[1].'-'.$tanggalArr[0].'</div>';
		echo '<div class="newsContent">'.$data['isi_berita']."</div><br/>";
	}
?>