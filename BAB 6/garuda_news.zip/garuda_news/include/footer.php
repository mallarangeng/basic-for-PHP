<div align="center" style="clear:both;">
	<div style="width:800px;text-align:center;height:350px;font-family:verdana;font-size:11px;padding-top:25px;">
		Garuda News &copy; <?php echo date("Y"); ?>
	</div>
</div>
</body>
</html>
