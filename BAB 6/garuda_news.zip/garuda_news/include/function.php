<?php
//Fungsi upload gambar
function uploadPicture($name){
	//Check existence file
	if((!empty($_FILES[$name])) && ($_FILES[$name]['error'] == 0)){
	  //Check filetype and size
	  $filename=basename($_FILES[$name]['name']);
	  $ext=strtolower(substr($filename,strlen($filename)-3,3));
	  //$filename= md5(uniqid(rand));
	  //$filename=strtolower($filename.'.'.$ext);
	  //if (($ext=="jpg") && ($_FILES[$name]['type'] == "image/jpeg") && ($_FILES[$name]['size'] < 350000)) {
	  if (($ext=="jpg") && ($_FILES[$name]['type'] == "image/jpeg")) {
		//get new name
		$newname = 'resources/'.$filename;
		  if ((move_uploaded_file($_FILES[$name]['tmp_name'],$newname))){
				return $newname;
		  } else {
				?>
					<script language="javascript" type="text/javascript">
						alert('Proses gagal. Tidak dapat memindahkan file.')
					</script>
				<?php
				exit();
		  }	
	  } else {
			?>
				<script language="javascript" type="text/javascript">
					alert('Hanya tipe file jpeg saja.')
				</script>
			<?php
			exit();
	  }
	}
}//end process

//Baca data
function readDate($date){
	if (!empty($date)){
		$dateArr = explode("-",$date);
		$date = $dateArr[2]."/".$dateArr[1]."/".$dateArr[0];
		
		return $date;
	}
}
?>