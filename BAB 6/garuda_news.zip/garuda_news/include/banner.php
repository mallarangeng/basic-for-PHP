<br/>
<div class="headerStyle">
	<div style="padding:4px 0px;">&nbsp;<img src="images/header_left.jpg"/>&nbsp;Banner</div>
</div>
	<br/>
<?php
	$result = mysql_query("SELECT * FROM banner") or die(mysql_error());
	while ($data = mysql_fetch_array($result)){
		echo '<a href="'.$data['link'].'"><img src="'.$data['gambar'].'" alt="banner"/></a><br/><br/>';
	}
?>