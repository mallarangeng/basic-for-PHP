<?php

	//Dapatkan nama kategori berita
	function getKategori($id){
		$result = mysql_query("SELECT kategori FROM kategori_berita WHERE id =".$id) or die(mysql_error());
		$data = mysql_fetch_array($result);
		return $data['kategori'];
	}
	
	if (empty($_REQUEST['catid']))
		$sqlstr = "SELECT * FROM berita ORDER BY tanggal DESC LIMIT 0,5";
	else
		$sqlstr = "SELECT * FROM berita WHERE id_kategori=".$_REQUEST['catid']." ORDER BY tanggal DESC LIMIT 0,5";
	
	$result = mysql_query($sqlstr) or die(mysql_error());
	
?>
<div style="width:100%; margin:px 5px;">
<?php
	if (!empty($_REQUEST['catid'])) echo '<div class="pageTitle" style="border-bottom:1px solid #fd0000;">'.getKategori($_REQUEST['catid']).'</div><br/>';
	while ($data = mysql_fetch_array($result)){
		echo '<div style="border-bottom:2px solid #ccc;"><a href="./?catid='.$data['id_kategori'].'&newsid='.$data['id'].'">'.$data['judul'].'</a><br/>';
		$tanggalArr = explode("-",$data['tanggal']);
		echo '<div class="datePublish">'.$tanggalArr[2].'-'.$tanggalArr[1].'-'.$tanggalArr[0].'</div>';
		echo '<div class="newsContent">'.substr($data['isi_berita'],0,350)."..."."</div></div><br/>";
	}
?>
</div>