<div class="headerStyle">
	<div style="padding:4px 0px;">&nbsp;<img src="images/header_left.jpg"/>&nbsp;Event</div>
</div>

<div style="width:98%">
<?php
	$sql = mysql_query("SELECT * FROM event WHERE selesai >= NOW() LIMIT 0,4") or die(mysql_error());
	if (mysql_num_rows($sql)>0){
		while ($data = mysql_fetch_array($sql)){
			echo '<div style="border-bottom:1px dotted #ccc; margin-bottom:3px;"><a href="event.php#'.$data['id'].'">'.$data['event']."</a><br/>";
			echo $data['tempat']."<br/>";
			echo readDate($data['mulai'])."-".readDate($data['selesai'])."<br/></div>";
		}
	?>
	<div style="text-align:right;">
		<a href="./event.php">Selengkapnya</a>
	</div>
	<?php
	}
?>
</div>