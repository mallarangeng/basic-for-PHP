<?php	
	//Cek apakah email telah terdaftar
	function cekEmail($email){
		$result = mysql_query("SELECT email FROM pelanggan_berita WHERE email = '".$email."'") or die(mysql_error());
		if ($result){
			if (mysql_num_rows($result) > 0)
				return true;
			else
				return false;
		}
	}
	
	//Simpan data
	if (isset($_REQUEST['subscribe'])){
		$email = mysql_real_escape_string($_REQUEST['email']);
		if (!cekEmail($email)){
			$dateJoin = date('Y-m-d H:i:s');
			$sqlstr = "INSERT INTO pelanggan_berita(email) VALUES ('".$email."')";
			$result = mysql_query($sqlstr) or die(mysql_error());
			$confirmation = ($result) ? "Email anda telah tersimpan." : "Tidak bisa menyimpan data.";
		}else{
			$confirmation = "Email anda telah terdaftar.";
		}
	}
?>
<script type="text/javascript">
	function validateEmailSubscription(emailValue){
		var pattern=/^([a-zA-Z0-9_.-])+@([a-zA-Z0-9_.-])+\.([a-zA-Z])+([a-zA-Z])+/;
		if (!pattern.test(emailValue)){
			alert('Harap masukkan format email yang benar.');
			return false;
		}else{
			
			return true;
		}
	}
</script>

<div class="headerStyle">
	<div style="padding:4px 0px;">&nbsp;<img src="images/header_left.jpg"/>&nbsp;Langganan Berita</div>
</div>
<?php
	echo $confirmation;
?>
<form method="post" action="<?php $_SERVER['PHP_SELF'] ?>" onsubmit="return validateEmailSubscription(document.getElementById('email').value)">
	E-Mail: <input type="text" name="email" id="email"/>
	<input type="submit" name="subscribe" value="Subscribe"/>
</form>