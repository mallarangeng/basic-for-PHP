<div id="bottomContent">
	<div class="bottomContentPanel">
		<?php require("include/event.php"); ?>
	</div>
	<div class="bottomContentPanel">				
		<?php 				
			if ($_REQUEST['mode'] == "view_polling_result")
				//lihat hasil polling
				require("include/polling_result.php"); 
			else	
				//polling
				require("include/polling.php"); 					
		?>
	</div>
	<div class="bottomContentPanel">
		<?php require("include/tell_friends.php"); ?>
	</div>
</div>