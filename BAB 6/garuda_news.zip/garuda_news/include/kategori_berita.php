	<br/>
	<div class="headerStyle">
		<div style="padding:4px 0px;">&nbsp;<img src="images/header_left.jpg"/>&nbsp;Kategori Berita</div>
	</div>
<?php
	$result = mysql_query("SELECT * FROM kategori_berita") or die(mysql_error());
	echo '<ul>';
	while ($data=mysql_fetch_array($result)){
		if ($_REQUEST['catid']==$data['id'])
			echo '<li style="color:#000;">'.$data['kategori'].'</li>';
		else
			echo '<li><a class="newsCategory" href="./?catid='.$data['id'].'">'.$data['kategori'].'</a><br/></li>';
	}
	echo '</ul>';
?>