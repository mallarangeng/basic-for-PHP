<?php
	ob_start();
	session_start();	
	require("config/dbconfig.php");
	require("include/function.php");
	
	function cekMyCookie(){
		if ($_COOKIE['rememberme'] && !empty($_COOKIE['userid'])){
			$_SESSION['login'] = true;
			$_SESSION['userid'] = $_COOKIE['userid'];
		}
	}
	cekMyCookie();
	
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Garuda News</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<?php
if (!empty($_REQUEST['catit']) && !empty($_REQUEST['newstit'])){ ?>
	<link rel="stylesheet" type="text/css" href="../css/style.css" />
<?php
}elseif (!empty($_REQUEST['catit'])){ ?>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
<?php
}else{
?>
<link rel="stylesheet" type="text/css" href="./css/style.css" />
<?php
}
?>
</head>

<body>
<table width="100%" border="0" cellpadding="0" cellspacing="0" height="297px" style="clear:both;">
<tr>
	<td id="bgheader">&nbsp;</td>
	<td width="768px" id="bgheader">
		<div>
			<div id="bgtagline">
				<div id="headertitle">
					<br/>
					<div style="font-size:11px;">
						<a class="topLink" href="./">Home</a> | <?php echo ($_SESSION['login']) ? '<a class="topLink" href="./logout.php">Logout</a> | <a class="topLink" href="./admin_panel.php">Admin Panel</a>':'<a class="topLink" href="./login.php">Login</a>';?>
					</div>
					<form method="get" action="search.php">
						<input type="text" name="q" value="Search..." onfocus="if (this.value=='Search...')this.value='';" onblur="if (this.value=='')this.value='Search...'" /><input type="submit" name="search" value="GO"/>
					</form>
					<br/><br/>
					<div style="font-family:tahoma;">GARUDA NEWS</div>
				</div>
				<div id="tagline">
					<ul>
						<li>&nbsp;&nbsp;Akurat</li>
						<li>&nbsp;&nbsp;Terkini</li>
						<li>&nbsp;&nbsp;Terpercaya</li>
					</ul>
				</div>
			</div>
			<div id="headerPicture">
				<img src="images/earth.png" alt="earth"/>
			</div>
		</div>
	</td>
	<td id="bgheader">&nbsp;</td>
</tr>
</table>

<div style="width:100%;text-align:center;">
	<div style="800px">
		<span style="width:25%"><a href="./index.php"><img src="images/butHome.jpg"/></a></span>
		<span style="width:25%"><a href="./event.php"><img src="images/butEvent.jpg"/></a></span>
		<span style="width:25%"><a href="./image_gallery.php"><img src="images/butImageGallery.jpg"/></a></span>
		<span style="width:25%"><a href="./contact_us.php"><img src="images/butContactUs.jpg"/></a></span>
	</div>
</div>
