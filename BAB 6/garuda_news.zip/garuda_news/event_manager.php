<?php
	require("include/header.php");

	if (!$_SESSION['login']){
		echo "Anda tidak berhak mengakses halaman ini.";
		exit();
	}
	
	//Fungsi baca data dari database
	function readDateJs($date){
		if (!empty($date)){
			$dateArr = explode("-",$date);
			$date = $dateArr[1]."/".$dateArr[2]."/".$dateArr[0];
			
			return $date;
		}
	}
	
	//Konversi tanggal ke format mysql(Y-M-D) ketika menyimpan data
	function convertDate($date){
		$dateArr = explode("/",$date);
		$date = $dateArr[2]."/".$dateArr[0]."/".$dateArr[1];		
		return $date;
	}
	
	//SIMPAN DATA
	if (isset($_REQUEST['simpan'])){
		$id = $_REQUEST['id'];
		$event = mysql_real_escape_string($_REQUEST['event']);
		$tempat = mysql_real_escape_string($_REQUEST['tempat']);
		$mulai = convertDate(mysql_real_escape_string($_REQUEST['mulai']));
		$selesai = convertDate(mysql_real_escape_string($_REQUEST['selesai']));
		$keterangan = mysql_real_escape_string($_REQUEST['keterangan']);
		
		if (empty($id))
			$sqlstr = "INSERT INTO event(event, tempat, mulai, selesai, keterangan) VALUES('".$event."','".$tempat."','".$mulai."','".$selesai."','".$keterangan."')";
		else
			$sqlstr = "UPDATE event SET event = '".$event."', tempat='".$tempat."', mulai='".$mulai."', selesai='".$selesai."', keterangan='".$keterangan."' WHERE id =".$id;
		
		$result = mysql_query($sqlstr) or die(mysql_error());
		
		$confirmation = ($result)? "Data telah tersimpan.":"Gagal menyimpan data.";
		$id = "";
		$event = "";
		$tempat = "";
		$mulai = "";
		$selesai = "";
		$keterangan = "";
	}
	
	//EDIT / DELETE MODE
	if (!empty($_REQUEST['id']) && !empty($_REQUEST['mode'])){
		if ($_REQUEST['mode'] == 'delete'){
			$result = mysql_query("DELETE FROM event WHERE id=".$_REQUEST['id']) or die(mysql_error());
			$confirmation = ($result)? "Data telah terhapus.":"Gagal menghapus data.";
		}elseif ($_REQUEST['mode'] == 'edit'){
			$result = mysql_query("SELECT * FROM event WHERE id=".$_REQUEST['id']) or die(mysql_error());
			$data = mysql_fetch_array($result);
			$id = $data['id'];
			$event = $data['event'];
			$tempat = $data['tempat'];
			$mulai = $data['mulai'];
			$selesai = $data['selesai'];
			$keterangan = $data['keterangan'];
		}
	}
	?>
<link rel="stylesheet" href="js/datepicker/ui.datepicker.css" type="text/css" media="screen" title="Flora (Default)" />
<script type="text/javascript" src="js/datepicker/jquery.js"></script>
<script type="text/javascript" src="js/datepicker/ui.datepicker.js"></script>
<script type="text/javascript">
	if (!window.console) {
		window.console = {
			log: function() {
				alert(arguments[0]);	
			}
		}
	}

	$(window).bind("load",function(){
		$.datepicker.setDefaults($.datepicker.regional['']);
		$(".demojs").each(function () {
			
			$('.codeLink').click(function() {
				$(this).hide().siblings('pre').show();
			});
			eval($(this).html());
		});
	});
	
</script>	
<div align="center">
	<div style="width:700px;text-align:left;padding-top:25px;">
	<div class="pageTitle">Event Manager</div>
	<?php echo $confirmation; ?><br/>
	<form method="post" enctype="multipart/form-data" action="<?php $_SERVER['PHP_SELF']?>">
		<table width="400px" border="0" cellpadding="0" cellspacing="0">
		<tr>
			<td>Event</td>
			<td>
				<input type="text" name="event" value="<?php echo $event; ?>"/>
				<input type="hidden" name="id" value="<?php echo $id; ?>"/>
			</td>
		</tr>
		<tr>
			<td>Tempat</td>
			<td><input type="text" name="tempat" value="<?php echo $tempat; ?>"/></td>
		</tr>
		<tr>
			<td>Mulai</td>
			<td>
				<input type="text" name="mulai" id="mulai"  value="<?php echo readDateJs($mulai); ?>" size="8"/>
				<script type="text/jsdemo" charset="utf-8" class="demojs">
				$('#mulai').datepicker({showOn: 'both', showOtherMonths: true, 
					showWeeks: true, firstDay: 1, changeFirstDay: false,
					buttonImageOnly: true, buttonImage: 'js/datepicker/calendar.gif'});	
				</script>
			</td>
		</tr>
		<tr>
			<td>Selesai</td>
			<td>
				<input type="text" name="selesai" id="selesai"  value="<?php echo readDateJs($selesai); ?>" size="8"/>
				<script type="text/jsdemo" charset="utf-8" class="demojs">
				$('#selesai').datepicker({showOn: 'both', showOtherMonths: true, 
					showWeeks: true, firstDay: 1, changeFirstDay: false,
					buttonImageOnly: true, buttonImage: 'js/datepicker/calendar.gif'});	
				</script>
			</td>
		</tr>
		<tr>
			<td valign="top">Keterangan</td>
			<td><textarea name="keterangan" cols="40" rows="6"><?php echo $keterangan; ?></textarea></td>
		</tr>
		<tr>
			<td colspan="2"><input type="submit" name="simpan" value="Simpan"/></td>
		</tr>
	</table>
	</form>
	<hr/>
	<table width="700px" border="1" cellpadding="2" cellspacing="0">
		<tr>
			<th>Event</th>
			<th>Tempat</th>
			<th>Mulai</th>
			<th>Selesai</th>
			<th>Action</th>
		</tr>
		<?php
		//LOAD USER
		$result = mysql_query("SELECT * FROM event");
		while ($data = mysql_fetch_array($result)){
		?>
			<tr>
				<td><?php echo $data['event'];?></td>
				<td><?php echo $data['tempat'];?></td>
				<td><?php echo readDate($data['mulai']);?></td>
				<td><?php echo readDate($data['selesai']);?></td>
				<td>
					<a href="./event_manager.php?id=<?php echo $data['id']; ?>&mode=delete">Hapus</a> | 
					<a href="./event_manager.php?id=<?php echo $data['id']; ?>&mode=edit">Edit</a>
				</td>
			</tr>
		<?php
		}
		?>
	</table>
	</div>
</div>
<?php	
	require("include/footer.php");
?>