<?php
	require("include/header.php");
	
	//Dapatkan id paling akhir untuk pertanyaan polling.
	function getLatestNewsId(){
		$result = mysql_query("SELECT MAX(id) AS maxId FROM berita") or die(mysql_error());
		if (mysql_num_rows($result) > 0){		
			$data = mysql_fetch_object($result);
			return $data->maxId;
		}else
			return 0;
	}
	
	//Kirim email berita baru kepada subscriber
	function kirimEmail($idKategori,$judul, $isiBerita){
		$isiBerita = substr($isiBerita, 0, 250);
		$newsId = getLatestNewsId();
		$result = mysql_query("SELECT email FROM pelanggan_berita") or die(mysql_error());
		if (mysql_num_rows($result) > 0){
			$subject = "Berita baru dari Garuda News";
			$content = "Ada berita baru di Garuda News<br/><br/>";
			$content .= '<b>'.$judul.'</b><br/><br/>'.$isiBerita.'<br/> Untuk selengkapnya <a href="http://www.garuda-news.co.cc/index.php?catid='.$idKategori.'&newsid='.$newsId.'">klik disini</a>.';
			$header = "from: admin@garudanews.co.cc \r\n";
			$header .= "Content-type: text/html";
			while ($data=mysql_fetch_array($result)){
				$content .= '<br/><br/><br/>Untuk berhenti berlangganan <a href="http://www.garuda-news.co.cc/unsubscribe.php?email='.$data['email'].'">klik disini.</a>';
				$kirim = mail($data['email'],$subject, $content, $header);				
			}
		}
	}
	
	//Load berita
	if (!empty($_REQUEST['id'])){
		$result = mysql_query("SELECT * FROM berita WHERE id =".$_REQUEST['id']) or die(mysql_error());
		$data = mysql_fetch_array($result);
		$id = $data['id'];
		$judul = $data['judul'];
		$isiBerita = $data['isi_berita'];
	}
	
	//Simpan berita dan konfirmasi kepada subscriber
	if (isset($_REQUEST['ok'])){
		$judul = $_REQUEST['judul'];
		$news = $_REQUEST['news'];
		$idKategori = $_REQUEST['kategori'];
		$tanggal = date('Y-m-d');
		if (empty($_REQUEST['id']))
			$sqlstr = "INSERT INTO berita(id_kategori, judul, isi_berita, tanggal)VALUES(".$idKategori.",'".$judul."','".$news."','".$tanggal."')";
		else
			$sqlstr = "UPDATE berita SET judul='".$judul."', isi_berita='".$news."' WHERE id=".$_REQUEST['id'];
		$result = mysql_query($sqlstr) or die(mysql_error());
		
		//Jika mode edit, maka tidak akan dikirimkan konfirmasi kepada subscriber
		if (empty($_REQUEST['id']))	kirimEmail($idKategori, $judul, $news);
		$confirmation = ($result) ? "Data telah tersimpan." : "Gagal menyimpan data.";	
	}
	?>
	<div align="center">
		<div style="width:800px;text-align:left;">
		<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
		<link href="ckeditor/content.css" rel="stylesheet" type="text/css"/>
		<?php echo $confirmation;?>
		<form method="post" action="<?php $_SERVER['PHP_SELF']?>">
			<input type="hidden" name="id" value="<?php echo $id; ?>"/>
			<input type="hidden" name="kategori" value="<?php echo $_REQUEST['kategori']; ?>"/>
			<table>
				<tr>
					<td>Judul</td>				
					<td><input size="50px" type="text" name="judul" value="<?php echo $judul; ?>"/></td>
				</tr>
				<tr>
					<td valign="top">Isi berita</td>				
					<td>
						<textarea cols="60" rows="10" id="news" name="news"><?php echo $isiBerita;?></textarea>
						<script type="text/javascript">
							var editor = CKEDITOR.replace('news');
						</script>
					</td>
				</tr>
				<tr>				
					<td><input type="submit" name="ok" value="Simpan"/></td>
				</tr>
			</table>
		</form>
		</div>
	</div>
<?php
	require("include/footer.php");
?>